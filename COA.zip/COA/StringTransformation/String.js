function transformString(str) {
    const length = str.length;

    // Check divisibility
    const divisibleBy3 = length % 3 === 0;
    const divisibleBy5 = length % 5 === 0;

    let result = str;

    if (divisibleBy3 && divisibleBy5) {
        // Divisible by 15
        result = result.split('').reverse().join('');
        result = result.split('').map(char => char.charCodeAt(0)).join('');
    } else if (divisibleBy3) {
        // Divisible by 3
        result = result.split('').reverse().join('');
    } else if (divisibleBy5) {
        // Divisible by 5
        result = result.split('').map(char => char.charCodeAt(0)).join('');
    }

    return result;
}

// Example usage:
const input1 = "Hamburger";
console.log(transformString(input1)); // Output: "regrubmaH"

const input2 = "Pizza";
console.log(transformString(input2)); // Output: "azziP"

const input3 = "Chocolate Chip Coohie";
console.log(transformString(input3)); // Output: "eihoocpihcetalocohc"
